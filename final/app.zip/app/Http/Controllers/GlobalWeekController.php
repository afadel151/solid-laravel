<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GlobalWeekController extends Controller
{
    //
}
