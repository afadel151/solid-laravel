<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LearningSessionController extends Controller
{
    //
}
